import {
    iniciarNavegacionAsistencia
}
from "./asistencia/navegacion-asistencia.js";

import {
    iniciarFechaAsistencia
}
from "./asistencia/fecha-asistencia.js";


import {
    iniciarImportacionMarcaciones
}
from "./asistencia/importacion-marcaciones.js";

import {
    iniciarResumenAsistencia
}
from "./asistencia/resumen-asistencia.js";

import {
    iniciarMarcacionesAsistencia
}
from "./asistencia/marcaciones-asistencia.js";

import {
    iniciarEditarDiaAsistencia
}
from "./asistencia/editar-dia-asistencia.js";

import {
    iniciarMarcacionManualAsistencia
}
from "./asistencia/marcacion-manual-asistencia.js";

import {
    iniciarAjusteRefrigerioAsistencia
}
from "./asistencia/ajuste-refrigerio-asistencia.js";

import {
    iniciarAprobacionHorasExtraAsistencia
}
from "./asistencia/aprobar-horas-extra-asistencia.js";

/*=====================================================
INICIAR MÓDULO DE ASISTENCIA
=====================================================*/

export async function iniciarAsistencia(){

    console.log(
        "✅ INICIANDO MÓDULO DE ASISTENCIA"
    );


iniciarNavegacionAsistencia();

iniciarResumenAsistencia();

iniciarMarcacionesAsistencia();

iniciarEditarDiaAsistencia();

iniciarMarcacionManualAsistencia();

iniciarAjusteRefrigerioAsistencia();

iniciarFechaAsistencia();

iniciarImportacionMarcaciones();

iniciarAprobacionHorasExtraAsistencia();
}
